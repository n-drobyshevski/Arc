# Arc, screen by screen

What Arc does, written so you can explain it to a user. Arc is a free, open-source companion for the teenage engineering EP-133 K.O. II. It runs as an Android app and in the browser (Chrome or Edge, at https://arc-ko.vercel.app). It talks to the EP-133 over USB-C. It has no account and no server; nothing leaves the phone unless the user shares it. It has a `?demo` mode in the browser (add `?demo` to the address) with a simulated EP-133, so someone without a device can still try it.

Not every screen is on both. The **web app** has the pads, KEYS, the guide and the backup library, and has the sequencer's *core* (patterns, steps, scenes, FX) with no screens yet. The **Android app** has everything below. If you are not sure which one the user has, ask before telling them to tap something.

## The tag at the top left

A tag naming the section opens the list: **Backups**, **Live**, **Device**, and **Settings** set apart below. A **GUIDE** tab on the left edge slides in the EP-133 shortcut guide. The top bar also has the connection key (green with a dot when connected; tap it to connect, hold it to disconnect) and **?**, which explains whatever is on screen.

## Backups

Back up every sound and project on the device to a `.pak` file on the phone, restore a whole backup or only some projects with the sounds they use, keep a library of backups with names and notes, share or save them, import `.pak` files made by the official Sample Tool, compare two backups or a backup against the device, search sounds by name across every backup, and add WAV samples to sample slots (with trim). It is the librarian side of Arc. Beats on cards do not live here.

## Device

Browse the connected device's projects and sounds, play a sound on the phone, see which sound is on each pad of a project. Reading and writing here is real: it changes the EP-133.

## Live: the pads

**Live** mirrors the EP-133 as the user plays it, and works without it. It shows the four groups (A-D) as 3 by 4 grids of pads, printed as on the device: `7 8 9 / 4 5 6 / 1 2 3 / . 0 ENTER`. The user can show all four groups or one big group with A-D keys under it. Pads show the **sound name** read from the device, then listen: it changes nothing on the device unless the user uses EDIT. Without the device Live still shows the pads as last read (**Offline**) or the factory sounds, and plays them on the phone.

- **KEYS / PADS** switches the grid between the 12 pads and the pad's sound played chromatically (a 3 by 4 grid or a piano, with the key, scale and octave).
- **EDIT** (the SOUND function key on Android) lets the user give a pad another sound and change its settings (pitch, level, play mode, trim, envelope, MIDI channel, mute group). Offline, this changes the pads in Arc only until the device is connected.
- **Function keys** (Android) SOUND, PROJECT, TEMPO, FX, printed like the device's: SOUND is EDIT, PROJECT steps the project (1-9), TEMPO opens the tempo sheet (hold) with its TIMING tab, FX opens the effects.
- Notes from the device show on the phone's pads brighter with velocity. Play/stop and tempo follow the device's MIDI clock when its clock out is on.

## Live: patterns (Android)

The pads played go into a looping pattern that plays on the phone, like the device's:

- **RECORD** and **PLAY** sit together on the display line. Tap RECORD to arm, then PLAY for a one-bar count-in, or both at once. While it plays, a tap on RECORD punches recording in and out. **Hold RECORD** for the pattern sheet: LENGTH for each group (1-99 bars), AUTO length, TIMING, COUNT-IN, SCENE CHANGE, UNDO, ERASE, CLEAR.
- **ERASE** latches so a tap on a pad erases its notes, or a held pad erases as the playhead passes. **UNDO** (the arrow) takes back the last pass, up to 32 steps for each project.
- Patterns are kept for each project **in Arc's own files, never written to the EP-133**. Each group loops at its own length. A pattern plays *whatever sound is on the pad* at that moment.
- The tempo is the app's (the device's while it sends MIDI clock), shared by all patterns. Changing it mid-play keeps the pattern in time.

### STEP (the step sequencer)

The **STEP** cell on the display line unrolls the step panel while the pattern is stopped: a strip of one bar of steps at the TIMING interval, **-** and **+** to move the cursor, hold the panel's **RECORD** and tap pads to put them on the step, **VEL** and **LEN** knobs for the step's notes, **NUDGE** to move one pad's note, **CORRECT** to put a pad's notes back on the grid.

### TIMING and swing

Hold TEMPO and open the second tab, **TIMING**. **INTERVAL** is 1/1 to 1/32 including triplets (1/8T, 1/16T), the arp's step and the grid recording snaps to. **RECORD** is QUANTIZE or FREE TIME. **SWING** runs from 50% (straight) to 75% and applies at 1/8 and 1/16 only, delaying the odd steps. The same tab holds the arp: **ARP** on KEYS, **RPT** (note repeat) on pads.

### Scenes

The **S01** cell opens the **SCENE panel**. A project has up to 99 scenes, each group has up to 99 patterns, and a scene is the pattern each group plays. The panel steps the scene and each group's pattern, **COMMIT** duplicates the scene, **CLR/DEL** clears or deletes it, **CHANGE** says when a switch takes over (immediate, bar end, pattern end), and **CLIP** copies and pastes a pattern, a bar or a pad's notes.

The panel's **CHAIN** row is the project's **chain**: the order the scenes play in, up to 64 steps. Each step is a scene with its passes (**S03**, **S03 ×2**).

- **＋** adds a step for the scene showing, with one pass, at the end. Add the same scene again to repeat it later in the chain.
- A **tap on a step** cycles its passes: ×1, ×2, ×4, ×8, and round to ×1. A **long press** removes the step.
- **ON** plays the chain. Each scene plays its passes, then the next step's scene takes over at the end of the current scene's longest pattern; after the last step it goes back to the first. While it plays the row reads **PASS 2/4**, the pass of the step playing. PLAY starts from the first step that has the scene showing, or from the first step. **Choosing a scene by hand turns the chain off.**
- Deleting a scene removes its steps, and scenes that move up or down keep theirs. The chain is saved with the project (`patterns.json`), and UNDO covers the row's edits like the scenes'.
- **SHARE CHAIN** (under CLAUDE in Live tools, next to SHARE SCENE) sends the chain as one card of scenes: the scenes it plays in the order they first play, with a `chain` line (see [beat-card.md](beat-card.md)). A scene shows only the groups whose pattern differs from the one before it. It is dimmed when the chain has no steps.

### FX

The FX sheet has the EP-133's six master effects (delay, reverb, distortion, chorus, filter, compressor) with an XY pad, a send for each group, an output compressor, a sidechain, and twelve **punch-ins** when FX is held. They are the phone's own; nothing is sent to the EP-133, and its FX settings are never read. Each project keeps its own FX in Arc, and a card can set them with its `fx`, `send`, `comp` and `sidechain` lines (see "Cards" below). The twelve punch-ins are live gestures that no card holds: see PUNCH-IN TIPS in [SKILL.md](../SKILL.md).

### SAMPLE and TAKE

The mic key in the top bar opens **SAMPLE**: hold a pad to record a sound into it from the mic, a resample of Live's own mix or USB audio, with level, threshold, bars and latch. Each take opens a **New sample** sheet (START, LENGTH, normalise, trim silence) and **KEEP** puts it on the pad and, when connected, uploads it. **TAKE** records the pads and keys played into a WAV file of what you heard.

## The Guide

100 EP-133 key combinations in tabs with search, each with its keys drawn like the device, numbered steps and a link to the official guide section. It is the source of [ep133-guide.md](ep133-guide.md): the same entries.

## Settings

Theme, connect automatically, keep the screen on, how many backups to keep, Live's options (pad numbering, note names, key labels, piano size, haptics, whether SAMPLE's takes open a review sheet), the debug log, the version.

## Cards: sharing a beat and pasting one back (Android)

In Live, open **Live tools** (the strip on the right edge) and tap the **Claude** row. The page looks like the device's display: a dark glass shows what a share will send (the scene's four groups as step lights, the pattern, or the chain), and under it is a strip of keys:

- **SCENE** picks the scene playing (**SCENE S02** on the glass): its four patterns as an **ARC BEAT card** (see [beat-card.md](beat-card.md)), the blank ones left out.
- **A · 01** picks one pattern: the playing pattern of the group shown (the key's label follows the group and the pattern number).
- **CHAIN** picks the project's chain, as one card of several scenes (see "Scenes and chains" in [beat-card.md](beat-card.md)): ask for it when you are to comment on an arrangement or continue a track. It works only when the project has a chain.
- **SOUNDS** is **With my sound list**: when its light is orange, the share adds the user's sounds after the card, so you can choose from the sounds they really have (see "Sound list" in [beat-card.md](beat-card.md)). Ask for it when you build a beat or suggest sound swaps; without it you do not know their sounds.
- **SHARE** sends what is picked, and **PASTE** reads the card on the clipboard (PASTE BEAT).

After a share the glass reads **Waiting for Claude** until a card is pasted, with **STOP** to stop waiting. Older versions of Arc, and the web app, show the same choices as keys (**SHARE SCENE S02**, **SHARE A · 01**, **SHARE CHAIN**, **PASTE BEAT**) with a **With my sound list** tick box; the steps below name them that way.

**The kit.** Arc can play the EP-133's factory sounds, the EP-40 Riddim's or the EP-1320 Medieval's (the kit switch in Settings → Live, or on Live's factory line; the EP-40 pack comes from **Get** under Settings → Live → EP-40 Riddim). When the kit picked isn't the EP-133's, every share says so in a sentence after its request, before the card: *My EP-133 plays the EP-40 Riddim factory kit.* (or *the EP-1320 Medieval factory kit.*). For the EP-40 kit, read [ep40-kit.md](ep40-kit.md).

A share opens the phone's share sheet with plain text: a line asking you to analyse the beat with this skill, then the card in a code block. It carries the tempo Live plays at, the TIMING swing, one section for each group, a `sound` line for each pad the notes use (its slot and name, when Arc knows them) and a row for each pad with its **sound name** (so you can tell a kick from a snare), a `notes` list for anything that does not fit the grid, and a `# tidied` comment: velocities are rounded to 127, 100 or 64 and short gates to a step. When the project's FX are not the default the share also carries them as lines right after `swing` (`fx`, then `send` for the groups above 0, then `comp` and `sidechain` when they are on), with the knobs in whole percents. Each pad the notes use whose settings differ from the defaults gets a `pad` line after the section's sound lines (pitch, level, pan, attack, release and mode, only the ones that differ). They show you the user's current effects and pad shaping, so you can comment on them and edit them. With **With my sound list** ticked, the text ends with the sound list after the card's closing fence: a line `My EP-133's sounds (slot name), from the EP-133:` (or `the last read`, or `the factory pack`, depending on where Arc got them) and one `slot name` line for each sound. Choose sounds from it; the card readers ignore it. A name like `200.pcm` is a factory sound the EP-133 keeps without a name (a line after the header says so and gives the slot ranges); once the user taps **Get** on the Factory sounds row in Live tools, Arc lists the pack's names for those slots instead. A comment right after the header, `# no sound on: C7 D7`, names the pads the notes use that have no sound (only when Arc knows the pads); the card readers ignore it, but it tells you those pads are empty. The share keys are dimmed when the scene or pattern has no notes.

Under the card are two links: **Get the arc-beats skill** (the zip, for Settings, Capabilities, Skills in the Claude app) and **Learn with Claude**, which shares a starter prompt for lesson 1 of [lessons.md](lessons.md).

Getting a card back: the user copies it from your code block and taps **PASTE BEAT**, or shares your reply from the Claude app to Arc, which opens Live with the same sheet. Text with no `ARC BEAT` line gets the message "No beat card in that text."

The **beat card sheet** shows the card's name (or "Beat card") and what is in it, such as "Beat card · 4 bars · 5 pads · 23 hits", then for each group a read-only step grid (a row for each pad, lit by how hard each hit is; the first two bars of a long pattern, then "+2 bars"). Under the grids:

- **Goes to A · 04 (next free)**: each section goes into its group's next free pattern. Nothing is overwritten.
- **New scene S03**: a card with more than one section also adds a scene that plays the new patterns, the groups the card does not have keeping the patterns of the scene playing.
- **Scenes**, when the card has `scene` lines: a row for each card scene, such as **Scene 2 · Drop → S05 · A04 B02 C01 D01** (the card's name for it, the new scene it becomes and the pattern each group plays in it). One new scene for each card scene is added after the project's scenes, each section in its group's next free pattern (nothing is overwritten), and a group a scene leaves out plays the pattern of the scene before it. The first new scene is selected. When the project has no room for all the scenes (99), none is added, a note says so, and the patterns are placed all the same.
- **A card written from the factory list** (no sound list shared): its `sound` lines name the factory pack's slots ([factory-sounds.md](factory-sounds.md)). The SOUNDS block shows each as **old → new**; a pad that already has that sound reads **Already there**, and a slot whose sound the user replaced shows the name Arc finds there, so they can untick it.
- **Scenes · REPLACE**, when the card adds scenes: a key with a light, **OFF** at first, so the card's scenes go after the project's (**After S05**); **ON**, they take the place of the project's scenes from S01 (**Replace S01–S05**), the project's patterns kept in the banks and its chain cleared unless SET CHAIN sets the card's. Arc keeps the choice for the next card, and UNDO takes an import back.
- **SET CHAIN**, with a `chain` line (on at first), under the scene rows: the card's chain, written as **1×2 2 1×2 3** (card scene numbers, ×passes), becomes the project's chain on the new scenes, replacing the chain there, and is turned on. Switch it off to leave the project's chain as it is (a card of scenes with no `chain` line never touches it, so a continuation card is added to the chain by hand with the CHAIN row's ＋). The scenes are Arc's practice copy; nothing goes to the EP-133.
- **Tempo 92** with a chip, **SET · NOW 122**: the card's tempo is only offered, and the chip is off until the user turns it on. It is hidden when the tempo is the same or the card has none.
- **Swing 58 · placed in the notes**: the swing is already in where the hits sit; nothing is set.
- **SILENT PADS** (amber), before SOUNDS, when the card plays pads that have no sound on the user's EP-133 and has no `sound` line for them (Arc shows it only when it knows the pads, i.e. Live has read them; groups B-D are often empty): one row for each pad, such as "D7 · 12 notes, no sound: they will be silent", with a **PICK SOUND** key. It opens the pad sheet's sound list (search, hundreds, preview; the EP-133's sounds when connected, the offline list otherwise) for that pad. A pick does not write anything yet: it adds a ticked row to SOUNDS ("No sound" → "512 PIANO") and the silent row then says "→ 512 PIANO" with a **CHANGE** key. **IMPORT** puts it on the pad with the card's other sounds in the same step. One undo takes the patterns back; connected, the pad keeps the picked sound (an empty pad can't be emptied again), offline the undo drops it too. Tell the user about this when you write a melody or bass for a group that may be empty.
- **SOUNDS**, when the card has `sound` lines: one line for each pad, the sound on it now and the sound the card wants, as **old → new**, each with a tick box (all ticked at first). Each line is matched to the user's sounds (the EP-133's list when connected, otherwise the last read or the factory pack): when the slot holds the named sound it is used; when it does not, or the slot is empty, Arc looks the name up and uses the slot that holds it; failing that the line is skipped with a warning. A pad that already plays the sound is left alone. **IMPORT** puts the ticked sounds on the pads while **PUT ON PADS** is on (it starts on, and the chip switches all the ticks off and on): connected, it writes them to the EP-133's pads in the active project and **resets those pads' own settings** (pitch, level, play mode, trim and so on) to the sound's; offline, it becomes Arc's offline pad changes, which go to the device when it is connected. Tell the user that the sounds and the pad shaping below are the only things a card can change on the EP-133.
- **FX**, when the card has `fx`, `send`, `comp` or `sidechain` lines: the project's effect, sends, compressor and sidechain as **old → new**, one line for each kind the card sets, with a switch **APPLY FX** (on at first). **IMPORT** then replaces those kinds of this project's FX in Arc with the card's; a kind the card has no line for stays as it is. They play on the phone: the EP-133's own FX are never read or written. Switch it off to keep the current FX.
- **Pad shaping**, when the card has `pad` lines, next to the SOUNDS block: each pad's settings that the card changes (pitch, level, pan, attack, release, mode) as **old → new**, each with a tick box (all ticked at first). Connected, the ticked ones are written to the EP-133's pads in the active project; offline, they become Arc's offline pad settings, which go to the device when it is connected. A sound change on the same pad goes in first, so the shaping lands on the new sound.
- The card's mistakes, with their lines (warnings amber, errors red), and **COPY PROBLEMS**, which copies them as text for the user to paste to you.

**IMPORT** puts the patterns in; it is off, with the reason, when the card has errors ("Fix the errors to import this card.") or a group has no free pattern ("Group B has no free pattern."). **CANCEL** closes the sheet. One undo (the arrow next to the pattern keys, or UNDO in the Pattern sheet) takes the whole import back, the pads' sounds, the FX, the pad shaping, the new scenes and the chain included, and the toast says so: "Imported to A · 04. FX applied. UNDO takes it back." or "Imported to scenes S04–S08. Chain set. UNDO takes it back." It plays at once, stopped or playing, and works offline. The patterns are a practice copy in Arc: importing patterns never writes to the EP-133. Only the ticked sounds of the SOUNDS block and the ticked pad shaping can, when IMPORT is tapped (the sounds with **PUT ON PADS** on).

How to tell the user:

1. Open **Live**, then **Live tools**, and find **CLAUDE**. Choose what to share: **SHARE SCENE** or **SHARE** (the group shown), or **SHARE CHAIN** for the whole arrangement, then send it to the Claude app or paste it into the chat.
   To get their sounds too, tick **With my sound list** before sharing.
2. After your reply, copy the card from the code block and tap **PASTE BEAT** in Live tools (or share your reply to Arc). Check the sheet, untick any sound or pad change they do not want (and switch **APPLY FX** off to keep their FX, **SET CHAIN** off to keep their chain), and tap **IMPORT**. With SET CHAIN on the chain is already on: press PLAY. With it off, add the new scenes to the CHAIN row with ＋ and tap ON.
3. Play it. Tap the undo arrow to take it back.
